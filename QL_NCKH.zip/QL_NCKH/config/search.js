$(document).ready(function() {
    $("#key").watermark("Nhập Từ Cần Tìm Kiếm");    // Watermart cho khung nhập
    $("#key").keyup(function()
    {
        var key = $(this).val();           // Lấy giá trị search của người dùng
        var dataString = 'keyword='+ key;    // Lấy giá trị làm tham số đầu vào cho file ajax-search.php
        if(key.length>2)                    // Kiểm tra giá trị người nhập có > 2 ký tự hay ko
        {
            $.ajax({
                type: "GET",                              // Phương thức gọi là GET
                url: "ajax-search.php",                  // File xử lý
                data: dataString,                        // Dữ liệu truyền vào
                beforeSend:  function() {                // add class "loading" cho khung nhập
                    $('input#key').addClass('loading');
                },
                success: function(server_response)        // Khi xử lý thành công sẽ chạy hàm này
                {
                    $('#searchresultdata').html(server_response).show();      // Hiển thị dữ liệu vào thẻ div #searchresultdata
                    $('span#faq_category_title').html(key);    // Hiển thị giá trị search của người dùng
                    
                    if ($('input#key').hasClass("loading")) {        // Kiểm tra class "loading"
                        $("input#key").removeClass("loading");        // Remove class "loading"
                    } 
                }
            });
        }return false;        // Không chuyển trang
    });
    });