
<?php	
	include("conection.php");
	session_start();
	

	if(isset($_POST['btn_dangnhap']))
	{
		$u=$l=$p="";
			 if($_POST['username'] == NULL)
			 {
			   echo "<script>alert('Bạn chưa nhập tên đăng nhập!!!'); 
		                location.href = 'login.php';</script>";
			 }
			 else
			 {
			  $u=$_POST['username'];
			 }
			 if($_POST['password'] == NULL)
			 {
				  echo "<script>alert('Bạn chưa nhập mật khẩu!!!'); 
		                location.href = '../login.php';</script>";
			  
			 }
			 else
			 {
			  $p=$_POST['password'];
			 }
			 if($u && $p)
			 {
			  $sql="select * from users,phanquyen where phanquyen.pq_IDHoSo = users.id  and users.username='".$u."' and users.password='".$p."'";
			 
			  $query=mysqli_query($conn,$sql);
			  
			  if(mysqli_num_rows($query) == 0)
			  {
			  echo "<script>alert('Tên đăng nhập hoặc mật khẩu không đúng, vui lòng nhập lại'); 
		                location.href = '../login.php';</script>";
					
			  }
			  else
			  {
			   $row=mysqli_fetch_array($query);
			  
			   $_SESSION['username'] = $row['username'];
			   $_SESSION['phanquyen1'] = $row['pq_MaQuyen'];
			   
			  if(isset($_SESSION['username'])) {
				if ($_SESSION['phanquyen1']=='admin') {
				 echo "<script>alert('Bạn đã đăng nhập thành công'); 
		                location.href = '../admin/admin.php';</script>";
				}else{
						 echo "<script>alert('Bạn đã đăng nhập thành công'); 
		                location.href = '../users/user.php';</script>";}
			}
				   

			
			  }
			 }
	}
?>
