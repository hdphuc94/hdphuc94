<?PHP
$conn = mysqli_connect("mysql.hostinger.vn","u873592380_phuc","m01696971094","u873592380_qlnc") or die("Không thể kết nối database");
	 //mysqli_select_db("ql_nckh",$conn);
	  mysqli_query($conn,"SET NAMES 'utf8'");
if (!$conn) {
	die("Không thể kết nối tới database! ".mysqli_connect_error());
	# code...
}
?>