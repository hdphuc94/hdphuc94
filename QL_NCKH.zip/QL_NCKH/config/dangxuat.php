 <?php
 if (!isset($_SESSION['username'])) {
 	// nếu người dùng chư đăng nhập và không có thông tin trong hệ thống.
 	$_SESSION  = array();
 } else {
 	// nếu có thông tin người dùng và đang đăng nhập sẽ xóa dữ liệu người dùng này
 	$_SESSION  = array();// xóa hết session
 	session_destroy();// loại bỏ session đã tạo
 	# code...
 }
 
   header('Location: ../index.php?index=trangchu');
?> 