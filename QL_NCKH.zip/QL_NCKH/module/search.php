<script type="text/javascript" src="../include/js/jquery-1.12.3.min.js"></script>
<link rel="stylesheet" type="text/css" href="../include/css/jquery-ui.css"/>
<script type="text/javascript" src="../include/js/jquery-ui.js"></script>
<script type="text/javascript">
$(document).ready(function()
{	
	//sử dụng autocomplete với input có id = key
	$( "input#key" ).autocomplete({
        source:'../config/search.php'; //link xử lý dữ liệu tìm kiếm
    });
   $('#btn-search').click(function(e){
    $('.span').css('color','red');
});
});
</script>
<form method="get" id="form_search" action="">
    <table>
        <tr>
            <td>
                <input type="text" name="key" id="key" style="400px" placeholder="Tìm kiếm tỉnh thành Việt Nam..." />
            </td>
        </tr>
        <tr>
        	<td>
        		<div class="span" name="">
        			bbbb
        		</div>
        	</td>
        </tr>
        <tr>
            <td align="center">
                 <button id="btn-search" type="submit" name="btn-search">Tìm kiếm</button>
            </td>
        </tr>
    </table>
</form>