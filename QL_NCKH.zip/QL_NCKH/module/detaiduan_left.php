<div>
	<?php							
	while ($r=mysqli_fetch_array($result)) {
									
?>
	<p class="row" style="background:#0D0D67; border-radius:10px;text-align:center;">
	<a href="#"> <?php echo $r['Cdt_TenCap'] ?> </a>
	</p>

<?php } ?>		
</div>