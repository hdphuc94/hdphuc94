
             

                                <h1 class="title">NCKH &amp; HTQT</h1>
                                                    
                                                    
                                <p >Khoa CNTT đã thực hiện 08 đề tài cấp Bộ, với 02 đề tài đã nghiệm thu xuất sắc, 02 đề tài chưa nghiệm thu. Các thành viên trong khoa tham gia 01 đề tài nhánh cấp nhà nước, 01 đề tài cấp Bộ Tài nguyên và Môi trường<br>
            Trong 6 năm qua, Khoa có 36 bài báo được đăng trên các tạp chí có uy tín trong và ngoài nước. Đặc biệt từ năm 2009 số lượng công bố quốc tế của khoa (bài báo được đăng trên các tạp chí quốc tế và báo cáo tại các hội nghị quốc tế) đã tăng lên nhanh chóng.<br>
            Khoa đã và đang thực hiện hơn 20 đề tài NCKH cấp trường trong giai đoạn 2006 2013 do cán bộ giảng dạy chủ trì.<br>
            Khoa đã chú trọng đẩy mạnh thực hiện các đề tài và dự án ứng dụng tin học trong quản lý nhà trường như đề tài tăng cường luồng thông tin nội bộ trên hệ thống mạng, đề tài xây dựng phần mềm quản lý đề tài khoa học, góp phần không nhỏ&nbsp; cải tiến website của trường. Trung tâm Tính toán và Tích hợp dữ liệu của khoa có vai trò đặc biệt quan trọng trong nghiên cứu và ứng dụng CNTT vào việc quản lý nhà trường.<br>
            Khoa CNTT thực hiện 24 đề tài NCKH sinh viên 2006  2013, trong đó có 01 đề tài được giải 3 của Trường ĐHNN Hà Nội vào năm 2007-2008, (đề tài mã số SV2007-25-33), nhiều đề tài đạt giải nhất và nhì tại Hội nghị NCKH sinh viên của trường và được vào vòng chung kết giải thưởng quốc gia VIFOTEC.<br>
            Khoa CNTT cũng đã tổ chức, huấn luyện sinh viên của trường tham dự các kỳ thi Olympic toàn quốc về tin học và toán học. Đặc biệt xuất sắc là kết quả các kỳ Olympic Toán học cho sinh viên toàn quốc do bộ môn Toán đảm nhiệm (2 giải nhất, 10 giải ba, 3 giải khuyến khích) trong những năm 2009-2011, đã góp phần không nhỏ nâng cao uy tín của Trường ĐHNN Hà Nội.<br>
            Trong giai đoạn 2006-2013 Khoa đã tổ chức nhiều sinh hoạt nghiên cứu khoa học cấp Khoa (10 lớp bồi dưỡng với các bài giảng chuyên đề về Tin Sinh học, hệ thống GIS vào ứng dụng quản lý tài nguyên, các phương pháp và phần mềm xử lý dữ liệu thống kê, mô hình toán tối ưu, nguyên lý tính toán song song …). Một số bộ môn đã bước đầu có các sinh hoạt khoa học chuyên đề trong năm học 2008  2009.<br>
            Trong khuôn khổ dự án CNTT 2006-2010 các cán bộ trong Khoa đã xây dựng nhiều ứng dụng CNTT và tổ chức nhiều lớp tập huấn nâng cao trình độ tin học cho cán bộ của toàn trường với tổng số hàng trăm cán bộ giảng dạy tham gia.</p>
            <p><img  alt="publications_vie" src="libraries/insert/publications_vie.png" width="493" height="352"></p>
            <div id="__tbSetup"></div>
                                                                        
    