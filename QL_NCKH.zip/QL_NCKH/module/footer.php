<link rel="stylesheet" type="text/css" href="../include/css/bootstrap.min.css"/>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 ">
			Nội dung cập nhật đầy đủ về các nghiên cứu khoa học được cập nhật liên tục đầy đủ và chi tiết. Mọi thông tin đều được cập nhật hàng tuần vào lúc 10:00 sáng thứ 6.
		</div>
		<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" style="border-left:solid 1px #FFF"">
			coppy right by @PhucHa<br>
					Đơn vị chủ quản: Công ty TNHH PHÚC HẠ
			<br>
					Ngõ 297- Ngô Xuân Quảng - Trâu Quỳ - Gia Lâm - Hà Nội
			<br>
			email: <a href="email:hdphuc94@gmail.com"> hdphuc94@gmail.com</a>
		</div>
       
