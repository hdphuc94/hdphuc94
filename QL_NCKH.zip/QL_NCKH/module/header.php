<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
					<img src="include/images/FITA.png" width="100px" height="100px">
				</div>
				<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">
					<h3 >KHOA CÔNG NGHỆ THÔNG TIN - HỌC VIỆN NÔNG NGHIỆP VIỆT NAM</h3>
					<BR>
					
				</div>