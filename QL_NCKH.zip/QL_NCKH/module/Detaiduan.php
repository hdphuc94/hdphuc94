<?php 
	include("config/conection.php"); 
	$sql1 = " SELECT * FROM detai" ;
	$query1 = mysqli_query($conn,$sql1);
	$rows1 = mysqli_num_rows($query1);
	$count= "SELECT COUNT(*) FROM detai";


?>				
<style type="text/css">
	.media{ margin: 10px 0;
		
		border-top:  solid 1px #44cc44;
		border-bottom:  solid 1px #44cc44;
		font-size: 12px;
		border-top:solid 1px;
		border-bottom: solid 1px; 
		text-align: center;;
		color: #FFF;
		background-color: ;
		 }
		 .media h4{
		 	color: #FFF;
		 	text-align: left;

		 }
		 .media img{
		 	width: 80px;
		 	height: 80px;
		 	margin: 5px 0;

		 }
		 #main {
		 	background-color: #2BA62B;
		 	color: #FFF;
		 	border-radius: 10px;
		 	padding-left: 10px;
		 	font-family: arial;
		 }
</style>
				<div class="main">
					<div class="row" id="main">
						<p>
							<h4>
								Đề tài dự án 
							</h4>
						</p>

					</div>
					<?php 
						$baitren_mottrang = 10;
						$sotrang = $rows1/$baitren_mottrang;
						$page2 = $_GET['page'];
						if ($page2 == '' || $page2 == 1) {
							
							$page4 =0;
						}
						else{
							
							$page4 = (intval($page2)*10)-10;
						}
						

						$rr="SELECT * FROM detai LIMIT $page4,10 ";
						$result =mysqli_query($conn,$rr);
						
						
						
					while ( $r=mysqli_fetch_array($result)) {
						
						
					?>

					<div class="media">
						<a class="pull-left" href="#">
							<img class="media-object" src="include/images/FITA.png" alt="Image" >
						</a>
						<div class="media-left">
							<h4 class="media-heading"><?php echo $r['Dt_TenDT']; ?></h4>
							<div class=" row" > 
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									<p> <a href="#">  Nội dung chi tiết </a> </p>
								</div>
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									<p> chủ nhiệm: <?php echo $r['Dt_IDChuNhiem']; ?> </p>
								</div>
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									<p> năm : <?php echo $r['Dt_NamThucHien']; ?>  </p>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
									<p>  thời gian thực hiện: <?php echo $r['Dt_NgayBatDau'] ."->". $r['Dt_NgayKetThuc']; ?>   </p>
								</div>
								<div class="col-xs-6 col-sm-6 6col-md-6 col-lg-6">
									<p>   Thành viên: <?php echo $r['Dt_ThanhVien']; ?> </p>
								</div>

							</div>
						</div>
					</div>
					<?php
					}
					?>

				</div>
				<div align="center">
					<ul class="pagination pagination-sm">
					<li><a href="?page=1">&laquo;</a></li>
					<?php 
						for ( $page = 1; $page <= $sotrang; $page ++ ) {
						echo "<li><a href='?page={$page}'>{$page}</a></li>";
					 }?>
					<li><a href="?page=<?php $a = (int)$sotrang; echo $a;?>">&raquo;</a></li>
				</ul>
				</div>
					


