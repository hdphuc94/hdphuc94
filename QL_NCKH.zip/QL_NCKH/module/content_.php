<?php 
	include("config/conection.php");
	$sql= "SELECT * FROM capdetai";
	$result = mysqli_query($conn,$sql);

?>


<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" id="ct_left">
				<?php 
					if (isset($_GET['index'])) {

						$set=$_GET['index'];
					switch ($set){
						case 'trangchu':
							echo "";
							break;
							case 'gioithieu':
							echo "";
							break;
								case 'detaiduan':
								include("module/detaiduan_left.php");
							break;
								case 'baibao':
								echo "";
							break;
								case 'sanphamkhoahoc':
							echo "";
							break;
								case 'dangnhap':
							header('location:login.php');
							break;
						default:;
							echo "";
							break;
					
														
									} 
					}
					else{
						echo "";
					}
				
					
				?>
				
				</div>
				<div class="col-xs-7 col-sm-7 col-md-7 col-lg-7" id="ct_mid">
					<div name="hienthi"></div>
					<?php 
					if (isset($_GET['index'])) {

						$set=$_GET['index'];
					switch ($set){
						case 'trangchu':
							include("gioithieu.php");
							break;
							case 'gioithieu':
							include("gioithieu.php");
							break;
								case 'detaiduan':
							include("module/Detaiduan.php");
							break;
								case 'baibao':
								include("module/baibao_index.php");
							break;
								case 'sanphamkhoahoc':
							include("module/sanphamkhoahoc_index.php");
							break;
							
						default:
							include("gioithieu.php");
							break;
					
														
									} 
					}
					else{
						include("detaiduan.php");
					}
					
					
					
					?>
					
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" id="ct_right">
					<div class="row" align="center" >
							<?php include("search.php") ?>
						</div>

					
					<div id="ct_r_lienket" align="center">
						
						<div >
							<b>Đơn vị liên kết</b>

						</div>
						<div >
							<a href="http://vnua.edu.vn"><img src="include/images/vnua.jpg" class="img-responsive" alt="Học viên Nông Nghiệp Việt Nam " width="100px" height="100px"></a>
							<br>
							<a href="http://www.vnua.edu.vn/khoa/fita/vi"><img src="include/images/FITA.png" class="img-responsive " width="100px" height="100px" alt="KHoa Công Nghệ Thông Tin " ></a>
							<br>
						</div>
					</div>
					<div id="ct_r_lienketkhac">
						Cái này hiển thị thông tin đang truy cập:
						hay để ngày tháng năm vào cũng khá hợp lý.
						hiển thị thêm cái nội dung của các liên kết google, facebook, twitter.com
					</div>
				</div>
				