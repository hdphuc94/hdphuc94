<?php 
	include("config/conection.php"); 
	$sql1 = " SELECT * FROM baibao" ;
	$query1 = mysqli_query($conn,$sql1);
	$rows1 = mysqli_num_rows($query1);
	$count= "SELECT COUNT(*) FROM detai";


?>				
<style type="text/css">
	.media{ margin: 10px 0;
		
		border-top:  solid 1px #44cc44;
		border-bottom:  solid 1px #44cc44;
		font-size: 12px;
		
		text-align: center;;
		color: #FFF;
		;
		 }
		 .media h4{
		 	color: #FFF;
		 	text-align: left;

		 }
		 .media img{
		 	width: 80px;
		 	height: 80px;
		 	margin: 5px 0;

		 }
		 #main {
		 	background-color: #2BA62B;
		 	color: #FFF;
		 	border-radius: 10px;
		 	padding-left: 10px;
		 	font-family: arial;
		 }
</style>
				<div class="main">
					<div class="row" id="main">
						<p>
							<h4>
								Bài báo
							</h4>
						</p>

					</div>
					<?php while ( $r=mysqli_fetch_array($query1)) {
						
						
					?>

					<div class="media">
						<a class="pull-left" href="#">
							<img class="media-object" src="include/images/FITA.png" alt="Image" >
						</a>
						<div class="media-left">
							<h4 class="media-heading"><?php echo $r['Bb_TenBB']; ?></h4>
							<div class=" row" > 
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									<p> <a href="#">  Nội dung chi tiết </a> </p>
								</div>
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									
								</div>
								<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
									<p> năm xuất bản : <?php echo 0; ?>  </p>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
									<p>  Tên tạp chí: <?php echo "đang cập nhật" ?>   </p>
								</div>
								<div class="col-xs-6 col-sm-6 6col-md-6 col-lg-6">
									<p>   Thành viên: <?php echo $r['Bb_ThanhVien']; ?> </p>
								</div>

							</div>
						</div>
					</div>
					<?php
					}
					?>
				</div>
					<ul class="pagination pagination-sm">
					<li><a href="detaiduan.php?dt_id=top">&laquo;</a></li>
					<li><a href="detaiduan.php?dt_id=<?php echo $r['Dt_ID'] ?>"><?php echo $r['Dt_ID'] ?></a></li>
					<li><a href="detaiduan.php?dt_id=bot">&raquo;</a></li>
				</ul>
					


