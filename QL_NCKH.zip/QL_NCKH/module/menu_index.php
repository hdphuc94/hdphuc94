
<?php 
	
	if (isset($_GET['index'])) {
		$index = $_GET['index'];
		switch ($index) {
			case 'gioithieu':
				$active1 = 'active';
				break;
			case 'detaiduan':
				$active2 = 'active';
				break;
			case 'baibao':
				$active3 = 'active';
				break;
			case 'sanphamkhoahoc':
				$active4 = 'active';
				break;
			case 'lienhe':
				$active5 = 'active';
				break;
			case 'trogiup':
				$active6 = 'active';
				break;
			case 'tructuyen':
				$active6 = 'active';
				break;
			case 'email':
				$active6 = 'active';
				break;	
			
			default:
				$active = '';
				break;
		}
	}
?>
<nav class="navbar navbar-default" role="navigation">
					<div class="container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							
							<a class=" navbar-brand" href="index.php?index=trangchu" name="trangchu">Trang chủ</a>
								
						</div>
				
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse navbar-ex1-collapse">
							<ul class="nav navbar-nav">
								<li class="<?php echo $active1 ?>"><a href="index.php?index=gioithieu">giới thiệu</a></li>
								<li class="<?php echo $active2 ?>"><a href="index.php?index=detaiduan" >Đề tài dự án</a></li>
								<li class="<?php echo $active3 ?>"><a href="index.php?index=baibao">Bài báo</a></li>
								<li class="<?php echo $active4 ?>"><a href="index.php?index=sanphamkhoahoc">Sản phẩm khoa học</a></li>
							</ul>
							
							<ul class="nav navbar-nav navbar-right">
								
								<li class="<?php echo $active5 ?>"><a href="index.php?index=lienhe">Liên hệ</a></li>
								<li class="dropdown <?php echo $active6 ?>">
									<a href="index.php?index=trogiup" class="dropdown-toggle" data-toggle="dropdown">Trợ giúp <b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="index.php?index=tructuyen">Trực tuyến</a></li>
										<li><a href="index.php?index=email">Email</a></li>
										
									</ul>
								</li>
								<li><a href="login.php">Đăng nhập</a></li>
							</ul>
						</div><!-- /.navbar-collapse -->
					</div>
				</nav>