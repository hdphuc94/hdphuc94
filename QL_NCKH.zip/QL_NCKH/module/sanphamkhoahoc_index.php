<div class="row" style="text-align:center;">
<h1 style="font-size:50px"><b>oh! Sorry</b></h1>
<h2>Nội Dung chưa được công bố!</h2>
</div>