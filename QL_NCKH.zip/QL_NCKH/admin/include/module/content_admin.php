<?php 
	
?>
				<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 panel-control" >
					
					<div>
						<?php include("include/module/left_content_admin.php");?>

					</div>
				</div>
				<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9" >
					<div class="row panel-default">
						<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
							<img src="../include/images/FITA.png" width="100px" height="100px">
						</div>
						<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
							 <b style="font-size: 20px;margin-top:30%">Trang quản trị dành cho ADMIN!</b> 
						</div>
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
							<div id="line" class="row" align="center">
								<form class="navbar-form " rolesearch action="#">
									<div class="form-group">
											<input type="text" class="form-control" placeholder="Search" >
									</div>
									<button type="submit" class="btn btn-default" >Tìm kiếm</button>
								</form>
							</div>
						</div>
						
						<hr>
					</div>
					
					<div>
					<?php 
					if (isset($_GET['admin'])) {

						$set=$_GET['admin'];
					switch ($set){
						case 'hoso':
							include("include/module/users/hoso_nguoidung.php");
							break;
							case 'detaiduan':
								include("include/module/detaiduan/detaiduan.php");
								if (isset($_GET['action'])) {
									switch ($_GET['action']) 
									{
										case 'sua':
											include("include/module/detaiduan/suadetai.php ");
											break;
										case 'xoa':
											include("include/module/detaiduan/detaiduan.php");
											break;
										
										default:
											include("include/module/detaiduan/detaiduan.php");
											break;
									}
									
									}
									
								
									break;
							case 'baibao':
							include("include/module/baibao/baibao_admin.php");
							break;
								case 'baocaothongke':
								include("include/module/thongke/baocao_thongke_admin.php");
							break;
							break;case 'nam':
								include("include/module/thongke/baocao_thongke_admin.php");	break;
							case 'qtth':
									if (isset($_GET['dx'])) {
									switch ($_GET['dx']) {
										case 'themdexuat':
											include("include/module/detaiduan/themdexuat_admin.php");
											break;
										case 'suadexuat':
											include("include/module/detaiduan/suadexuat_admin.php");
											break;
										
										default:
											
											break;
									}
									break;	
									}			
						default:
							echo "";
							break;
					
														
									} 
					}
					else{
						echo "";
					}
				
					
				?>
						
					</div>
					<div class="row modal-footer">
						<?php include("../module/footer.php") ?>
					</div>	
				</div>
					
				
				