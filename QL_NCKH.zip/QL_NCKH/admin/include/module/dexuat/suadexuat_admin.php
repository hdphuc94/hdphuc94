<?php 
	include("../config/conection.php");
	$sql1 = " SELECT * FROM detai ";
	$result1 = mysqli_query($conn,$sql1);
?>

<style type="text/css">
	#frm_themdx tr td {

		height: 70px;
		padding-left: 10%;

		
	}
	#them_dx {
		border: solid 1px;
		width: 50%;
	}
	#them_dx2 {
		border: solid 1px;
		margin: 2% 4%;
	}
	#frm_themdx{
		width: 80%;
		margin-left: 10%;
		
	}
	.txt{
		text-align: left;
	}

</style>
<div style="margin-left: 20%;" id="them_dx" >
	<div align="center"> <h2>THÊM DỀ XUẤT ĐỀ TÀI NGHIÊN CỨU KHOA HỌC</h2></div>	
	<div id="them_dx2">
		<form action="" method="post" name="frm" id="frm_themdx">
		<table >
			<?php 
				$row1 = mysqli_fetch_array($result1)
				

			?>
			<tr>
				<td class="txt">
					ID
				</td>
				<td>
					<input type="text"  disabled="disabled" value="<?php $row1['Dt_ID']?>" />

				</td>
                
			</tr>
			<tr>
				<td class="txt">
					Tên đề tài
				</td>
				<td>
					<input type="text" name="id" value=" <?php $row1["Dt_TenDT"] ?> ">
				</td>
			</tr>
			<tr>
				<td  class="txt">
					Tính cấp thiết
				</td>
				<td>
					<textarea name="Tinhcapthiet"></textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Mục Tiêu
				</td>
				<td>
					<input type="text" name="Muctieu">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Nội dung chính
				</td>
				<td>
					<textarea name="nd_chinh" ></textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Kết quả dự kiến
				</td>
				<td>
					<textarea name="kq_dk">
						
					</textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Thời gian nghiên cứu dự kiến
				</td>
				<td>
					<input type="text" name="thoigian_dk">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Nhu cầu kinh phí dự kiến
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
		    
			<tr>
				<td colspan=2"" align="center">
					
					<input type="submit" name="btn_them" value="Sửa" >
				</td>
				
			</tr>
		    
		</table>
		</form>
	</div>
</div>
<?php 
	
		
	if (isset($_POST['btn_them'])) 
	{
		$id = $_POST['id'];
		$Ten_dt = $_POST['Ten_dt'];
		$Tinhcapthiet = $_POST['Tinhcapthiet'];
		$Muctieu = $_POST['Muctieu'];
		$nd_chinh = $_POST['nd_chinh'];
		$kq_dk = $_POST['kq_dk'];
		$thoigian_dk = $_POST['thoigian_dk'];
		$Nhucau_kp  = $_POST['Nhucau_kp'] ;
		
		
		if ($Ten_dt == NULL || $Tinhcapthiet == NULL || $Muctieu == NULL || $nd_chinh == NULL || $kq_dk == NULL || $thoigian_dk == NULL || $Nhucau_kp == NULL || $Nhucau_kp == NULL) {
			echo "<script>alert('Các ô không được bỏ trống!');</script>";
		}else{
			$sql = " UPDATE  detai SET  Dt_TenDT = '$Ten_dt',,Dt_NoiDung = '$nd_chinh', ,Dt_TInhCapThiet = '$Tinhcapthiet',Dt_MucTieu = '$kq_dk',Dt_KetQuaDuKien = '$Muctieu',Dt_ThoiGianDuKien = '$thoigian_dk',Dt_NhuCauKinhPhiDuKien = '$Nhucau_kp' Where Dt_ID =  $id";
			$result = mysqli_query($conn,$sql);
		echo "<script>alert('Bạn đã nhập thành công!');</script>";
		}
		
	} else {

		echo "a = ";}
?>
