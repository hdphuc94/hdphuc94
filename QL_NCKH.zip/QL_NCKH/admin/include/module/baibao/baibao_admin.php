<?php 
	include("../config/conection.php");
	

	$sqlselectdt = "SELECT * FROM baibao INNER JOIN linhvuc ON baibao.Bb_IDLinhVuc = linhvuc.Lv_ID ";
	$rerult = mysqli_query($conn,$sqlselectdt);
	$count = mysqli_num_rows($rerult);
	
	
?>
<style type="text/css">
	table tr td {
		text-align: center;
	}
</style>

<table  class="table " >
	<tr class="table-active" style="background:blue;color:#FFF;">
		<td scope="row">STT</td>
		<td>Tên bài báo</td>
		<td>Tên tạp chí</td>
		<td>Từ khóa</td>
		<td> Thành viên</td>
		<td>Lĩnh vực</td>
		<td>Sửa/Xóa</td>
		

	</tr>
	<?php while ($row= mysqli_fetch_array($rerult) ){

			
		
	 ?>
	<tr class="table-success">
		<td><?php echo $row['Bb_ID'] ?></td>
		<td><?php echo $row['Bb_TenBB'] ?></td>
		<td><?php echo $row['Bb_TenTapChi'] ?></td>
		<td><?php echo $row['Bb_TuKhoa'] ?></td>
		<td><?php echo $row['Bb_ThanhVien'] ?></td>
		<td>
			<?php echo $row['Lv_TenLV'] ?>
			
		</td>
		
		<td><a  href="#">Sửa</a>/<a  href="#">Xóa</a></td>

	</tr>
	<?php } ?>

</table>
			
	<ul class="pagination pagination-sm">
		<li><a href="detaiduan.php?dt_id=top">&laquo;</a></li>
		<?php for ($i=0 ; $i <  $count/10; $i++ ) { 
						# code...
		 ?>
		<li><a href="detaiduan.php?dt_id=<?php echo $i+1; ?>"> <?php echo $i+1;?></a></li>
	<?php }?>
		<li><a href="detaiduan.php?dt_id=bot">&raquo;</a></li>
	</ul>
				





