
<nav class="navbar navbar-default" role="navigation" style="font-size: 13px; ">
					<div class="container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse navbar-ex1-collapse">
							<ul class="nav navbar-nav">
								<li class=""><a href="admin.php?admin=hoso" class="">HỒ SƠ</a></li>
								<li><a href="admin.php?admin=detaiduan">ĐỀ TÀI DỰ ÁN</a></li>
								<li><a href="admin.php?admin=baibao">BÀI BÁO</a></li>
								<li><a href="admin.php?admin=baocaothongke">BÁO CÁO THỐNG KÊ</a></li>
							</ul>
							
							<ul class="nav navbar-nav navbar-right">
								<li style="color:red"> <a href="../config/dangxuat.php">Đăng xuất</a></li>
								
							</ul>
						</div><!-- /.navbar-collapse -->
					</div>
				</nav>