<?php 
	include("../config/conection.php");
	$sqlselectdt = "select * from users where username = username ";
	$rerult = mysqli_query($conn,$sqlselectdt);

?>

<table class="table table-responsive">
	<tr class="table-active table-hover table-striped">
		<td>STT</td>
		<td>ID</td>
		<td>Username</td>
		<td>password</td>
		<td>Tên thật</td>
		<td>Chức vụ </td>
		<td>Lớp</td>
		<td>Ngày sinh</td>
		<td>Email</td>
		<td>activated</td>
		<td>hành động</td>
		


	</tr>
	<?php $i=1; while ($row= mysqli_fetch_array($rerult)) {
		# code...
	 ?>
	<tr>
		<td><?php echo $i ?></td>
		<td><?php echo $row['id'] ?></td>
		<td><?php echo $row['username'] ?></td>
		
		<td><?php echo $row['password'] ?></td>
		<td><?php echo $row['tenthat'] ?></td>
		<td><?php echo $row['chucvu'] ?></td>
		<td><?php echo $row['lop'] ?></td>
		<td><?php echo $row['ngaysinh'] ?></td>
		<td><?php echo $row['email'] ?></td>
		<td><?php echo $row['activated'] ?></td>
		
		<td><a href="#" >Sửa</a><a href="#" >Xóa</a></td>
		



	</tr>
	<?php $i++;} ?>
</table>








