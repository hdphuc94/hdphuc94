<?php 
	include("../config/conection.php");
	
	
	$sqlselectdt1 = "SELECT DISTINCT Dt_NamThucHien FROM detai , linhvuc,loaidetai Where detai.Dt_IDLinhVuc = linhvuc.Lv_ID AND  detai.Dt_IDLoaiDT=loaidetai.Ldt_ID   ORDER BY Dt_NamThucHien DESC";
	$rerult1= mysqli_query($conn,$sqlselectdt1);
	
	
?>
<style type="text/css">
	table tr td {
		text-align: center;
	}
</style>
<div class="row">
	<h2><b>Báo cáo thống kê</b></h2> 
	
	<form method="post" action=" " name="frm">
		<select name="Nam" >
		<option value="0" selected="selected">lựa chọn năm</option>
		<?php  
			
		while ($r=mysqli_fetch_array($rerult1)) {
		
		?>
		<option  value="<?php echo $r['Dt_NamThucHien']; ?>" name="<?php echo $r['Dt_NamThucHien']; ?>">
			<?php echo $r['Dt_NamThucHien']; ?>	
			 
		</option>

		<?php } 
		
		?>
	</select>
		<input type="submit" name="loc" value="Lọc" >

	</form>
<?php
	
	
	if (isset($_POST['loc'])) {
			
				$f = $_REQUEST['Nam'];

				}
		else
		{
			$f=0;
			
		} 
	$sqlselectdt = "SELECT * FROM detai , linhvuc,loaidetai WHERE detai.Dt_IDLinhVuc = linhvuc.Lv_ID AND detai.Dt_IDLoaiDT=loaidetai.Ldt_ID AND detai.Dt_NamThucHien  LIKE '%$f%'"; 
	$rerult = mysqli_query($conn,$sqlselectdt);
	$count = mysqli_num_rows($rerult);
	echo $count."<br>".$sqlselectdt;
	?>
	
	
	
</div>
<table  class="table " >
	<tr class="table-active" style="background:blue;color:#FFF;">
		<td scope="row">STT</td>
		<td>Loại đề tài</td>
		<td>Lĩnh vực</td>
		<td>Tên đề tài</td>
		<td> Ngày đề xuất</td>
		<td>Ngày bắt đầu</td>
		<td>Ngày kết thúc</td>
		<td>Năm thực hiện</td>
		<td>ID chủ nhiệm</td>
		<td>Thành viên</td>
		<td>Tình trạng</td>
		<td>Phê duyệt</td>
		<td>Mã số</td>
		<td>Sửa/Xóa</td>


	</tr>
	<?php while ($row= mysqli_fetch_array($rerult)) {
		# code...
	 ?>
	<tr class="table-success">
		<td><?php echo $row['Dt_ID'] ?></td>
		<td><?php echo $row['Ldt_TenLDT'] ?></td>
		<td><?php echo $row['Lv_TenLV'] ?></td>
		<td><?php echo $row['Dt_TenDT'] ?></td>
		<td><?php echo $row['Dt_NgayDeXuat'] ?></td>
		<td><?php echo $row['Dt_NgayBatDau'] ?></td>
		<td><?php echo $row['Dt_NgayKetThuc'] ?></td>
		<td><?php echo $row['Dt_NamThucHien'] ?></td>
		<td><?php echo $row['Dt_IDChuNhiem'] ?></td>
		<td><?php echo $row['Dt_ThanhVien'] ?></td>
		<td><?php echo $row['Dt_TinhTrang'] ?></td>
		<td><?php echo $row['Dt_PheDuyet'] ?></td>
		<td><?php echo $row['Dt_Maso'] ?></td>
		<td><a  href="#">Sửa</a>/<a  href="#">Xóa</a></td>

	</tr>
	<?php } ?>

</table>
			
				<ul class="pagination pagination-sm">
					<li><a href="detaiduan.php?dt_id=top">&laquo;</a></li>
					<?php for ($i=0 ; $i <  $count/10; $i++ ) { 
						
					 ?>
					<li><a href="?dt_id=<?php echo $i+1; ?>"> <?php echo $i+1;?></a></li>
				<?php }?>
					<li><a href="detaiduan.php?dt_id=bot">&raquo;</a></li>
				</ul>
				





