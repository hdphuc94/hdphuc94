<?php
//<ul class="nav">
							
//							<li> <a href="admin.php?admin=nam">Thống kê theo năm</a> </li>
						
//							<li class="drodown"> <a href="admin.php?admin=tg ">Thống kê theo tên tác giả</a>
//							</li>
//							<li class=""> <p><a href="admin.php?admin=qtth&qt=tkldt">Thống kê theo loại đề tài </a></p></li>
									
//							</li>
//						</ul>
?>