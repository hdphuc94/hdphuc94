<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
					<img src="../include/images/FITA.png" width="100px" height="100px">
				</div>
				<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10" style="padding: 20px 0; font_size: 50px">

					<h4>QUẢN LÝ NGHIÊN CỨU KHOA HỌC - KHOA CÔNG NGHỆ THÔNG TIN</h2>
					<BR>
					<?php
									
									echo "<b style='font_size: 30px;color:#dd4b39 ;'> Xin chào: ".$_SESSION['username']."!</b>";

								?>  
				</div>
