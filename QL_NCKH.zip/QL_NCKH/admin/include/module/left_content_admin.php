

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../include/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="include/css/admin_left.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="../include/js/jquery-1.12.3.min.js"></script>
<div class="nav-side-menu">
    <div class="brand">
    	<div> <img src="../include/images/aaq.jpg" width="40px" height="40px"> avtar</div>
    	<div>Xin chào: <?php echo "<span style='color:red;'>".$_SESSION['username']."</span>!</b>"; ?></div>
    	
    </div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <li>
                  <a href="#">
                  <i class="fa fa-dashboard fa-lg"></i> công việc
                  </a>
                </li>

                <li  data-toggle="collapse" data-target="#products" class="collapsed active">
                  <a href="admin.php?Detaiduan"><i class="fa fa-gift fa-lg"></i> Đề tài dự án <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="products">
                    <li class="active"><a href="?Detaiduan?admin=dexuat"> Quản lý đề xuất</a></li>
                    <li><a href="admin.php?Detaiduan?admin=Thuyetminh"> Quản lý thuyết minh</a></li>
                    <li><a href="admin.php?Detaiduan?admin=tiendo"> Quản lý tiến độ</a></li>
                    <li><a href="admin.php?Detaiduan?admin=nghiemthu"> Quản lý nghiệm thu - báo cáo</a></li>
                   
                </ul>


                <li data-toggle="collapse" data-target="#service" class="collapsed">
                  <a href="?Baibao"><i class="fa fa-globe fa-lg"></i> Bài báo <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                  <li><a href="admin.php?Baibao?admin=bb-n">Bài bái theo năm</li>
                  <li><a href="admin.php?Baibao?admin=bb-l">Bài báo theo loại</li>
                  <li><a href="admin.php?Baibao?admin=bb-tg">Bài báo theo tên tác giả</li>
                </ul>


                <li data-toggle="collapse" data-target="#new" class="collapsed">
                  <a href="admin.php?Thongke"><i class="fa fa-car fa-lg"></i> Thống kê <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                  <li><a href="admin.php?Thongke?admin=thongke-theonam">Bhống kê theo năm</li>
                  <li><a href="admin.php?Thongke?admin=thongke-theotentacgia">Bhống kê theo tên tác giả</li>
                  <li><a href="admin.php?Thongke?admin=thongke-theoloai">Bhống kê theo loại</li>
                </ul>


                 <li>
                  <a href="?admin=hoso">
                  <i class="fa fa-user fa-lg"></i> Hồ sơ người dùng
                  </a>
                  </li>

                 <li>
                  <a href="../config/dangxuat.php">
                  <i class="fa fa-users fa-lg"></i> Đăng xuất
                  </a>
                </li>
            </ul>
     </div>
</div>