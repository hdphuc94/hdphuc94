<ul class="nav">
							
							<li> <a href="admin.php?admin=ldt">Loại đề tài</a> </li>
							<li> <a href="">Lĩnh vực</a> </li>
							<li class="drodown"> <a href="admin.php?admin=qtth ">Quá trình thực hiện</a>
								<ul class="">
									<li class=""><p> <a href="admin.php?admin=qtth?qt=dexuat">Đề xuất </a></p><p>
										<ul class=" ">
											<li><p><a href="admin.php?admin=qtth?dx=themdexuat">Thêm đề xuất</a></p></li>
											
										</ul>

									</li>
									<li class=""> <p><a href="admin.php?admin=qtth?qt=thuyetminh">Thuyết minh </a></p></li>
									<li class=""> <p><a href="admin.php?admin=qtth?qt=baocao">Báo cáo</a> </p> </li>
									<li class=""> <p><a href="admin.php?admin=qtth?qt=nghiemthu">Nghiệm thu</a> </p> </li>
								</ul>
							</li>
						</ul>
