<?php 
	include("../config/conection.php");
	$sua = $_GET['dt_id'];
	$sql1= "SELECT * FROM detai WHERE Dt_ID = $sua";
	$result1 = mysqli_query($conn,$sql1);
	$row= mysqli_fetch_array($result1);
?>
<style type="text/css">
	#frm_themdx tr td {

		height: 70px;
		padding-left: 10%;

		
	}
	#them_dx {
		border: solid 1px;
		width: 50%;
	}
	#them_dx2 {
		border: solid 1px;
		margin: 2% 4%;
	}
	#frm_themdx{
		width: 80%;
		margin-left: 10%;
		
	}
	.txt{
		text-align: left;
	}

</style>
<div style="margin-left: 20%;" id="them_dx" >
	<div align="center"> <h2>SỬA ĐỀ TÀI NGHIÊN CỨU KHOA HỌC Mã ID : <?php echo .$row['Dt_ID']?></h2></div>	
	<div id="them_dx2">
		<form action="" method="post" name="frm" id="frm_themdx">
		<table >
			
			<tr>
				<td class="txt">
					Tên đề tài
				</td>
				<td>
					<input type="text" name="Ten_dt" value="<?php ?>">
				</td>
			</tr>
			<tr>
				<td  class="txt">
					Loại Đề Tài
				</td>
				<td>
					<textarea name="Tinhcapthiet"></textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Lĩnh Vực
				</td>
				<td>
					<input type="text" name="Muctieu">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Ngày Đề Xuất
				</td>
				<td>
					<textarea name="nd_chinh" ></textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Ngày bắt đầu
				</td>
				<td>
					<textarea name="kq_dk">
						
					</textarea>
				</td>
			</tr>
			<tr>
				<td class="txt">
					Ngày kết thúc
				</td>
				<td>
					<input type="text" name="thoigian_dk">
				</td>
			</tr>
			<tr>
				<td class="txt">
					năm thực hiện
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
		    <tr>
				<td class="txt">
					ID chủ nhiệm
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Thành viên
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Tình trạng
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Phê duyệt
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
			<tr>
				<td class="txt">
					Mã số
				</td>
				<td>
					<input type="text" name="Nhucau_kp">
				</td>
			</tr>
			
			<tr>
				<td colspan=2"" align="center">
					
					<input type="submit" name="btn_them" value="Thêm" >
				</td>
				
			</tr>
		    
		</table>
		</form>
	</div>
</div>
<?php 
	
		
		$Ten_dt = $_POST['Ten_dt'];
		$Tinhcapthiet = $_POST['Tinhcapthiet'];
		$Muctieu = $_POST['Muctieu'];
		$nd_chinh = $_POST['nd_chinh'];
		$kq_dk = $_POST['kq_dk'];
		$thoigian_dk = $_POST['thoigian_dk'];
		$Nhucau_kp  = $_POST['Nhucau_kp'] ;
		$DT_NgayDeXuat = date("Y/m/d");
	if (isset($_POST['btn_them'])) 
	{

		
		if ($Ten_dt == NULL || $Tinhcapthiet == NULL || $Muctieu == NULL || $nd_chinh == NULL || $kq_dk == NULL || $thoigian_dk == NULL || $Nhucau_kp == NULL || $Nhucau_kp == NULL) {
			echo "<script>alert('Các ô không được bỏ trống!');</script>";
		}else{
			$sql = " INSERT INTO detai( Dt_TenDT,Dt_NgayDeXuat,Dt_NoiDung,Dt_TInhCapThiet,Dt_MucTieu,Dt_KetQuaDuKien,Dt_ThoiGianDuKien,Dt_NhuCauKinhPhiDuKien ) VALUES ('$Ten_dt','$DT_NgayDeXuat','$nd_chinh','$Tinhcapthiet','$Muctieu','$kq_dk','$thoigian_dk','$Nhucau_kp')";
			$result = mysqli_query($conn,$sql);
		echo "<script>alert('Bạn đã nhập thành công!');</script>";
		}
		
	} else {

		echo "a = ";}
?>