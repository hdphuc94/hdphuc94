<?php 

	 session_start();
	 include('../config/conection.php');
	 
?>
<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Quản trị quản lý nghiên cứu khoa học - Khoa Công Nghệ Thông Tin</title>

		<!-- Bootstrap CSS -->
		
		<link rel="stylesheet" type="text/css" href="../include/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="include/css/AdminLTE.min.css">
        
        
		<link rel="stylesheet" type="text/css" href="include/css/admin.css">
        
        
        <link rel="stylesheet" type="text/css" href="include/css/blue.css">
        <link rel="stylesheet" type="text/css" href="include/css/jquery-jvectormap-1.2.2.css">
        <link rel="stylesheet" type="text/css" href="include/css/daterangepicker-bs3.css">
        <link rel="stylesheet" type="text/css" href="include/css/bootstrap3-wysihtml5.min.css">
        
		<script src="../include/js/jquery-1.12.3.min.js"></script>
		<script src="../include/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="" >
			<div >
				<?php include("include/module/content_admin.php") ?>
				
			</div>
			
		</div>
		
	</body>
</html>