
$(document).ready(function()
{  
    //sử dụng autocomplete với input có id = key
    $( "input#key" ).autocomplete({
        source:'../../module/search.php', //link xử lý dữ liệu tìm kiếm
    })
});

